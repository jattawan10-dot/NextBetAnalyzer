# Next Bet Analyzer Android App

This is a native Android Studio project for a floating statistical analyzer.

## What is included
- Floating `NEXT CANDIDATES` overlay above other apps.
- Persistent history of the 10 configured outcomes: 2x, 5x, 8x, 18x, 20x, 30x, 50x, 66x, 88x, 100x.
- Candidate ranking based on overall frequency, recent frequency and observed transitions.
- Screen-monitor permission flow using Android MediaProjection/foreground-service declarations.
- Manual result buttons as a reliable fallback/calibration mode.

## Important
The current source does NOT claim to predict a hidden/server RNG result. The screen-monitor service is the safe foundation for adding game-specific visual recognition. Automatic logo/result recognition requires a clear screenshot/template of the exact game UI so the detector can be calibrated to the game's history strip/current result region.

Open in Android Studio, sync Gradle, build and install.
