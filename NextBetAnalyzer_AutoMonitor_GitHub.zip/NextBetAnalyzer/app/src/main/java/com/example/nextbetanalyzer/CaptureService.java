package com.example.nextbetanalyzer;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import java.nio.*;
import java.util.*;

public class CaptureService extends Service {
    static final String CH="capture";
    MediaProjection projection; VirtualDisplay display; ImageReader reader; Handler handler; ScreenDetector detector;
    SharedPreferences prefs;
    @Override public void onCreate(){ super.onCreate(); handler=new Handler(Looper.getMainLooper()); prefs=getSharedPreferences(MainActivity.PREF,0); detector=new ScreenDetector();
        if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel(CH,"Screen monitor",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager.class).createNotificationChannel(c); }
    }
    @Override public int onStartCommand(Intent i,int f,int id){
        if(Build.VERSION.SDK_INT>=29) startForeground(12,notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION); else startForeground(12,notification());
        if(projection!=null) return START_STICKY;
        int rc=i.getIntExtra("resultCode",0); Intent data=i.getParcelableExtra("data");
        if(data!=null){ MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE); projection=m.getMediaProjection(rc,data); projection.registerCallback(new MediaProjection.Callback(){public void onStop(){stopSelf();}},handler); startCapture(); }
        return START_STICKY;
    }
    void startCapture(){
        android.util.DisplayMetrics dm=getResources().getDisplayMetrics(); int w=dm.widthPixels,h=dm.heightPixels,d=dm.densityDpi;
        reader=ImageReader.newInstance(w,h,android.graphics.PixelFormat.RGBA_8888,2);
        display=projection.createVirtualDisplay("NextBetAnalyzer",w,h,d,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
        reader.setOnImageAvailableListener(r->{ Image img=r.acquireLatestImage(); if(img==null)return; try { Bitmap b=toBitmap(img); detector.process(b, this::record); } finally { img.close(); } },handler);
    }
    Bitmap toBitmap(Image image){
        Image.Plane p=image.getPlanes()[0]; ByteBuffer buf=p.getBuffer(); int ps=p.getPixelStride(), rs=p.getRowStride(); int extra=rs-ps*image.getWidth();
        Bitmap raw=Bitmap.createBitmap(image.getWidth()+extra/ps,image.getHeight(),Bitmap.Config.ARGB_8888); raw.copyPixelsFromBuffer(buf);
        Bitmap out=Bitmap.createBitmap(raw,0,0,image.getWidth(),image.getHeight()); raw.recycle(); return out;
    }
    void record(String value){
        synchronized(CaptureService.class){
            String s=prefs.getString("h",""); String[] a=s.isEmpty()?new String[0]:s.split("\\|",-1);
            if(a.length>0 && a[a.length-1].equals(value)) return;
            ArrayList<String> list=new ArrayList<>(Arrays.asList(a)); list.add(value);
            while(list.size()>200) list.remove(0);
            prefs.edit().putString("h",String.join("|",list)).putLong("last_detect",System.currentTimeMillis()).apply();
        }
    }
    Notification notification(){return new Notification.Builder(this,CH).setContentTitle("Next Bet Analyzer").setContentText("Automatic screen monitoring active").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build();}
    @Override public void onDestroy(){ if(reader!=null)reader.close(); if(display!=null)display.release(); if(projection!=null)projection.stop(); if(detector!=null)detector.close(); super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
}
