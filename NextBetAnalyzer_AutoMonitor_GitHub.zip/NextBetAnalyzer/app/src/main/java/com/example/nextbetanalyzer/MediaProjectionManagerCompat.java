package com.example.nextbetanalyzer;
import android.app.*;import android.content.*;import android.media.projection.MediaProjectionManager;import android.os.Build;
public final class MediaProjectionManagerCompat{
 public static final int REQ=501;
 public static void launch(Activity a){ MediaProjectionManager m=(MediaProjectionManager)a.getSystemService(Context.MEDIA_PROJECTION_SERVICE); a.startActivityForResult(m.createScreenCaptureIntent(),REQ); }
}
