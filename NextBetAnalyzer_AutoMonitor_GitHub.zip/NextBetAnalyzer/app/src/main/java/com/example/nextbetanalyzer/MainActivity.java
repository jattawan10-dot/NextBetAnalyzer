package com.example.nextbetanalyzer;

import android.app.*;import android.content.*;import android.media.projection.MediaProjectionManager;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;

public class MainActivity extends Activity {
 public static final String PREF="history"; static final int CAPTURE=1001;
 Button start,overlay,clear; TextView status;
 @Override public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,24,24,24);
  TextView title=new TextView(this);title.setText("Next Bet Analyzer\nAutomatic screen monitor");title.setTextSize(22);l.addView(title);
  status=new TextView(this);status.setText("\n1) Start automatic monitor\n2) Allow screen capture\n3) Open the game — results are detected and saved automatically.");l.addView(status);
  start=new Button(this);start.setText("START AUTO MONITOR");l.addView(start); overlay=new Button(this);overlay.setText("SHOW FLOATING PANEL");l.addView(overlay); clear=new Button(this);clear.setText("CLEAR HISTORY");l.addView(clear); setContentView(l);
  start.setOnClickListener(v->startMonitor()); overlay.setOnClickListener(v->showOverlay()); clear.setOnClickListener(v->{getSharedPreferences(PREF,0).edit().remove("h").apply();status.setText("History cleared.");});
 }
 void startMonitor(){
  if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));return;}
  MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE); startActivityForResult(m.createScreenCaptureIntent(),CAPTURE);
 }
 void showOverlay(){if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));return;} startService(new Intent(this,OverlayService.class));}
 @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r==CAPTURE&&c==RESULT_OK&&data!=null){startService(new Intent(this,CaptureService.class).putExtra("resultCode",c).putExtra("data",data));showOverlay();status.setText("\nAUTO MONITOR ACTIVE\nScreen is being analyzed with your permission.\nHistory and candidates update automatically.");}}
}
