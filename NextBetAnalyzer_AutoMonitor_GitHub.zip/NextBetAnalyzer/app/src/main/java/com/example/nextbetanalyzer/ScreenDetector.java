package com.example.nextbetanalyzer;

import android.graphics.Bitmap;
import android.util.Log;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.Text;
import java.util.*;
import java.util.regex.*;

public final class ScreenDetector {
    public interface Callback { void onDetected(String value); }
    private static final Pattern MULT = Pattern.compile("(?<!\\d)(100|88|66|50|30|20|18|8|5|2)\\s*[xX]?");
    private final com.google.mlkit.vision.text.TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private long lastMs=0; private String last="";
    public void process(Bitmap full, Callback cb){
        long now=System.currentTimeMillis();
        if(now-lastMs<700) { full.recycle(); return; } lastMs=now;
        // Ignore the bottom betting controls where 20/100/500/1K/5K are shown.
        int cropH=(int)(full.getHeight()*0.78f);
        Bitmap crop=Bitmap.createBitmap(full,0,0,full.getWidth(),Math.max(1,cropH));
        full.recycle();
        recognizer.process(InputImage.fromBitmap(crop,0)).addOnSuccessListener(result->{
            String hit=findLatest(result); crop.recycle();
            if(hit!=null && !hit.equals(last)){ last=hit; cb.onDetected(hit); }
        }).addOnFailureListener(e->{ crop.recycle(); Log.w("NextBet", "OCR failed", e); });
    }
    private String findLatest(Text result){
        ArrayList<String> hits=new ArrayList<>();
        for(Text.TextBlock b:result.getTextBlocks()) for(Text.Line l:b.getLines()){
            Matcher m=MULT.matcher(l.getText()); while(m.find()) hits.add(normalize(m.group(1)));
        }
        if(hits.isEmpty()) return null;
        // Prefer values in the known result set; de-duplication is handled by the caller.
        return hits.get(hits.size()-1);
    }
    private String normalize(String n){ return n+"x"; }
    public void close(){ recognizer.close(); }
}
