package com.example.nextbetanalyzer;

import java.util.*;

public final class Analyzer {
    public static final String[] OPTIONS = {"2x PSG","5x Bayern","8x Man United","18x Team","20x Al Hilal","30x Team","50x GFC","66x Team","88x Al Ahly","100x Team"};
    private final List<String> history;
    public Analyzer(List<String> history){ this.history=history; }
    public List<String> candidates(){
        Map<String,Integer> freq=new HashMap<>(), trans=new HashMap<>();
        for(String x:history) freq.put(x,freq.getOrDefault(x,0)+1);
        if(history.size()>1){ String last=history.get(history.size()-1); for(int i=0;i<history.size()-1;i++) if(history.get(i).equals(last)){String n=history.get(i+1);trans.put(n,trans.getOrDefault(n,0)+1);} }
        ArrayList<String> out=new ArrayList<>(Arrays.asList(OPTIONS));
        out.sort((a,b)->Double.compare(score(b,freq,trans),score(a,freq,trans)));
        return out.subList(0,Math.min(3,out.size()));
    }
    private double score(String x,Map<String,Integer> f,Map<String,Integer> t){
        int recent=0; int from=Math.max(0,history.size()-10); for(int i=from;i<history.size();i++) if(history.get(i).equals(x)) recent++;
        return f.getOrDefault(x,0) + recent*1.5 + t.getOrDefault(x,0)*2.0;
    }
    public String confidence(){ return history.size()<5?"Low":history.size()<15?"Medium":"Historical"; }
}
