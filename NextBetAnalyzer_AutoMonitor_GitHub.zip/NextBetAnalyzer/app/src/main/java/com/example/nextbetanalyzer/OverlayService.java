package com.example.nextbetanalyzer;

import android.app.*;import android.content.*;import android.graphics.Color;import android.graphics.PixelFormat;import android.os.*;import android.view.*;import android.widget.*;import java.util.*;

public class OverlayService extends Service{
 WindowManager wm; View panel; Handler h=new Handler(Looper.getMainLooper()); Runnable update=()->{render();h.postDelayed(update,1000);};
 public int onStartCommand(Intent i,int f,int id){show();return START_STICKY;}
 void show(){if(panel!=null)return; wm=(WindowManager)getSystemService(WINDOW_SERVICE); LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(14,9,14,9);box.setBackgroundColor(Color.argb(235,15,18,25));
  TextView title=new TextView(this);title.setTextColor(Color.WHITE);title.setTextSize(13);box.addView(title);panel=box; WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL;p.y=70;wm.addView(panel,p);update.run();}
 void render(){if(panel==null)return; ArrayList<String> hist=new ArrayList<>();String s=getSharedPreferences(MainActivity.PREF,0).getString("h","");if(!s.isEmpty())hist.addAll(Arrays.asList(s.split("\\|",-1)));Analyzer a=new Analyzer(hist);StringBuilder z=new StringBuilder("AUTO • NEXT CANDIDATES\n"); if(!hist.isEmpty())z.append("Last detected: ").append(hist.get(hist.size()-1)).append("\n"); for(String x:a.candidates())z.append("• ").append(x).append("\n");z.append("History: ").append(hist.size()).append(" | ").append(a.confidence());((TextView)((LinearLayout)panel).getChildAt(0)).setText(z.toString());}
 public void onDestroy(){if(panel!=null&&wm!=null)wm.removeView(panel);h.removeCallbacks(update);super.onDestroy();} public IBinder onBind(Intent i){return null;}
}
